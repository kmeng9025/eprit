function surfs = view_image_stack(im, scale, varargin)

nxy = 10;
sz = size(im);
nslices = sz(3);
usealpha = 0;
if (nargin > 2)
    maskvol = varargin{1};
    usealpha = 1;
    alphafac = 0.8/nslices
end
positions = 1:nslices;
positions = (positions -nslices/2)* scale(3);
x = linspace(-sz(2)/2,sz(2)/2,nxy) * scale(1);
y = linspace(-sz(1)/2,sz(1)/2,nxy) * scale(2);
z = ones(nxy,nxy);
figure;
plot_3d_axes(max(x));

surfs=[];
for n = 1:nslices
    s = surface(x,y,positions(n)*z,squeeze(im(:,:,n)),'Parent',gca,'FaceColor','texturemap',...
        'EdgeColor','none','CDataMapping','scaled');
    if (usealpha)
        mymask=squeeze(maskvol(:,:,n));
        mymask(find(mymask < 1)) = alphafac;
        set (s, 'FaceAlpha','texturemap','AlphaData',mymask,...
            'AlphaDataMapping','none');
    end
    surfs = [surfs s];
end

