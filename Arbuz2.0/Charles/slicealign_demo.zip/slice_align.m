function varargout = slice_align(varargin)
% SLICE_ALIGN M-file for slice_align.fig
%      SLICE_ALIGN, by itself, creates a new SLICE_ALIGN or raises the existing
%      singleton*.
%
%      H = SLICE_ALIGN returns the handle to a new SLICE_ALIGN or the handle to
%      the existing singleton*.
%
%      SLICE_ALIGN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SLICE_ALIGN.M with the given input arguments.
%
%      SLICE_ALIGN('Property','Value',...) creates a new SLICE_ALIGN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before slice_align_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to slice_align_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help slice_align

% Last Modified by GUIDE v2.5 19-Dec-2007 08:41:11
global myhandles tmats rmats nslices active myplanes xgrids ygrids zgrids...
    original_opacity global_opacity selected_opacity

if nargin  && isnumeric(varargin{1})
    myhandles = varargin{1};
    nslices = prod(size(myhandles));
    tmats = zeros(4,4,nslices);
    rmats = zeros(4,4,nslices);
    active = zeros(1,nslices);
    myplanes = [];
    xgrids = zeros(size(get(myhandles(1),'ZData')));
    ygrids = xgrids;
    zgrids = xgrids;
    parent = get(myhandles(1),'Parent');
    for n=1:nslices
        rmats(:,:,n) = eye(4,4);
        tmats(:,:,n) = eye(4,4);
        xd= get(myhandles(n), 'XData');
        yd= get(myhandles(n), 'YData');
        zg= get(myhandles(n), 'ZData');
        if isvector(xd)
            [xg, yg] = meshgrid(xd, yd);
        else
            xg = xd;
            yg = yd;
        end
        
        xgrids(:,:,n)=xg;
        ygrids(:,:,n)=yg;
        zgrids(:,:,n)=zg;
        myplanes(n) = surf(xg, yg, zg, [0 0.5 0], 'FaceColor','none',...
            'EdgeColor',[0 0.6 0],'EdgeAlpha',0.3,'Visible','off','Parent',parent);
    end    
    alphadata = get(myhandles(1),'AlphaData');
    original_opacity = min(alphadata(:));
    global_opacity = original_opacity;
    selected_opacity = min([0.1 2*original_opacity]);
    clear alphadata;
end
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @slice_align_OpeningFcn, ...
                   'gui_OutputFcn',  @slice_align_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before slice_align is made visible.
function slice_align_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to slice_align (see VARARGIN)

global checkboxes nslices global_opacity selected_opacity showgrids
% Choose default command line output for slice_align
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
checks = findobj(hObject,'Style','checkbox');
checkboxes=checks(end:-1:1);
nchecks = prod(size(checkboxes));
for n=1:nchecks
    if strcmp(get(checkboxes(n),'Tag'), 'grid_checkbox'), continue, end
    if (n <= nslices)
        set(checkboxes(n), 'String',['Slice ' num2str(n)]);
    else
        set(checkboxes(n),'Visible','off');
    end
end
set(handles.global_opacity,'String',num2str(global_opacity,'%10.2f'));
set(handles.selected_opacity,'String',num2str(selected_opacity,'%10.2f'));
showgrids = get(handles.grid_checkbox, 'Value');
%set(handles.grid_checkbox,'Visible','on');


% UIWAIT makes slice_align wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = slice_align_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in checkbox1.
function checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox1
global active checkboxes nslices myplanes global_opacity selected_opacity ...
    showgrids myhandles

for n=1:nslices
    ifactive = get(checkboxes(n),'Value');
    if (ifactive ~= active(n))
        active(n) = ifactive;
        alphadata = get(myhandles(n),'alphadata');                
        if (ifactive)
            if(showgrids), set(myplanes(n), 'Visible','on'); end
            alphadata(alphadata < 1.0) = selected_opacity;
        else
            set(myplanes(n), 'Visible','off');
            alphadata(alphadata < 1.0) = global_opacity;            
        end
        set(myhandles(n),'AlphaData',alphadata);
    end
end


% --- Executes on slider movement.
function xslider_Callback(hObject, eventdata, handles)
% hObject    handle to xslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global myhandles tmats rmats nslices active myplanes
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

thisx=get(hObject,'Value');
set(hObject,'Value',0.0);
thismat = hmatrix_translate([thisx 0 0]);
for n = 1:nslices
    if active(n), tmats(:,:,n) = tmats(:,:,n) * thismat; end
end
update_planes;

% --- Executes during object creation, after setting all properties.
function xslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to xslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function yslider_Callback(hObject, eventdata, handles)
% hObject    handle to yslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global myhandles tmats rmats nslices active myplanes
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

thisy=get(hObject,'Value');
set(hObject,'Value',0.0);
thismat = hmatrix_translate([0 thisy 0]);
for n = 1:nslices
    if active(n), tmats(:,:,n) = tmats(:,:,n) * thismat; end
end
update_planes;

% --- Executes during object creation, after setting all properties.
function yslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to yslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function zslider_Callback(hObject, eventdata, handles)
% hObject    handle to zslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global myhandles tmats rmats nslices active myplanes
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

thisz=get(hObject,'Value');
set(hObject,'Value',0.0);
thismat = hmatrix_translate([0 0 thisz]);
for n = 1:nslices
    if active(n), tmats(:,:,n) = tmats(:,:,n) * thismat; end
end
update_planes;

% --- Executes during object creation, after setting all properties.
function zslider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to zslider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
function rotate_slider_Callback(hObject, eventdata, handles)
% hObject    handle to rotate_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global myhandles tmats rmats nslices active myplanes
% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider
thisang=get(hObject,'Value') * 90.0;
set(hObject,'Value',0.0);
thismat = hmatrix_rotate_z(thisang);
for n = 1:nslices
    if active(n), rmats(:,:,n) = rmats(:,:,n) * thismat; end
end
update_planes;

% --- Executes during object creation, after setting all properties.
function rotate_slider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rotate_slider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end

function update_planes

global myhandles tmats rmats nslices active xgrids ygrids zgrids

for n=1:nslices
    if (active(n))
        xg=xgrids(:,:,n);
        yg=ygrids(:,:,n);
        zg=zgrids(:,:,n);
        xyz = [xg(:) yg(:) zg(:)];
        xyzt = htransform_vectors(rmats(:,:,n)*tmats(:,:,n), xyz);
        xgt = reshape(xyzt(:,1), size(xg));
        ygt = reshape(xyzt(:,2), size(yg));
        zgt = reshape(xyzt(:,3), size(zg));
        set(myhandles(n),'XData',xgt,'YData',ygt,'ZData',zgt);
    end
end


% --- Executes on button press in color_button.
function color_button_Callback(hObject, eventdata, handles)
% hObject    handle to color_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global myhandles
set(0,'CurrentFigure',get(get(myhandles(1),'Parent'),'Parent'));
colormapeditor;



function global_opacity_Callback(hObject, eventdata, handles)
% hObject    handle to global_opacity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global global_opacity myhandles nslices original_opacity
% Hints: get(hObject,'String') returns contents of global_opacity as text
%        str2double(get(hObject,'String')) returns contents of global_opacity as a double
newval = str2num(get(hObject,'String'));
if isempty(newval), newval = original_opacity; end
if (newval > 0.99) newval = 0.99;end
if (newval < 0) newval = 0; end
set(hObject, 'String', num2str(newval,'%10.2f'));
global_opacity = newval;

for n=1:nslices
    alphadata = get(myhandles(n),'AlphaData');
    alphadata(find(alphadata < 1)) = global_opacity;
    set(myhandles(n),'AlphaData',alphadata);
end
% --- Executes during object creation, after setting all properties.
function global_opacity_CreateFcn(hObject, eventdata, handles)
% hObject    handle to global_opacity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in grid_checkbox.
function grid_checkbox_Callback(hObject, eventdata, handles)
% hObject    handle to grid_checkbox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global showgrids nslices myplanes active
% Hint: get(hObject,'Value') returns toggle state of grid_checkbox
showgrids = get(hObject, 'Value');
for n=1:nslices
    if active(n)
            if(showgrids), 
                set(myplanes(n), 'Visible','on'); 
            else
                set(myplanes(n), 'Visible','off');
            end
    end
end

function selected_opacity_Callback(hObject, eventdata, handles)
% hObject    handle to selected_opacity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of selected_opacity as text
%        str2double(get(hObject,'String')) returns contents of selected_opacity as a double
global selected_opacity original_opacity nslices myhandles active

newval = str2num(get(hObject,'String'));
if isempty(newval), newval = original_opacity; end
if (newval > 0.99) newval = 0.99;end
if (newval < 0) newval = 0; end
set(hObject, 'String', num2str(newval,'%10.2f'));

selected_opacity = newval;
for n=1:nslices
    if active(n)       
        alphadata = get(myhandles(n),'AlphaData');                       
        alphadata(alphadata < 1.0) = selected_opacity;
        set(myhandles(n),'AlphaData',alphadata);
    end
end


% --- Executes during object creation, after setting all properties.
function selected_opacity_CreateFcn(hObject, eventdata, handles)
% hObject    handle to selected_opacity (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


