function maskvol = auto_mask_volume(im)

maskvol = zeros(size(im));
globalmax = max(im(:));

nslices = size(im,3);

for n = 1:nslices
    myslice = squeeze(im(:,:,n));
    [npix,xout] = hist(myslice(:), 100);
    posderivs = find(diff(npix) > 0);
    npeak = find(npix == max(npix(:)));
    nfew = find(npix < 0.1 * max(npix));  % histogram bins that 
                                              % are not very full
    nfewright = nfew(min(find(nfew > npeak))); % well down the peak
    
    threshold1 = xout(posderivs(min(find(posderivs > nfewright))));
    mymask = myslice;
    mymask(find(mymask < threshold1)) = 0;
    mymask(find (mymask > 0)) = 1;
    %[l,num] = bwlabel(mymask);
    %pixels = zeros(num,1);
  
    %for nl=1:num
    %    pixels(nl) = prod(size(find(l == nl)));
    %end
    
    %nlmax = find(pixels == max(pixels(:)));
    %for ln = 1:size(nlmax,1)
    %    mymask(find(l ~= nlmax(ln))) = 0;
    %end % retain only the largest component(s)
    
    mymask = imfill(mymask,'holes');
    mymask = bwmorph(mymask,'erode');
    mymask = bwmorph(mymask,'dilate');

    maskvol(:,:,n) = mymask;
end
        
