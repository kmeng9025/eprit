automask=auto_mask_volume(R21_57_DL_rare2AxImg);
surfs=view_image_stack(R21_57_DL_rare2AxImg,R21_57_DL_rare2Ax.scale,automask);
colormap(bone);
slice_align(surfs)